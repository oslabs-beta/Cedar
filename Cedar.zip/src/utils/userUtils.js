// import 'regenerator-runtime'

// export const getCredentials = async ()